package com.chinaway.tms.admin.dao;

import com.chinaway.tms.admin.model.SysDictionary;
import com.chinaway.tms.core.BaseMapper;

public interface SysDictionaryMapper extends BaseMapper<SysDictionary, Integer> {
	
}