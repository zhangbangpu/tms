package com.chinaway.tms.otd.dao;

import com.chinaway.tms.otd.model.Otd;
import com.chinaway.tms.core.BaseMapper;

public interface OtdMapper extends BaseMapper<Otd, Integer> {
	
}