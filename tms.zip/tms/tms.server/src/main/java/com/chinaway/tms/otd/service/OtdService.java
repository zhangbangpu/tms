package com.chinaway.tms.otd.service;

import com.chinaway.tms.otd.model.Otd;
import com.chinaway.tms.core.BaseService;

public interface OtdService extends BaseService<Otd, Integer> {
	
}
