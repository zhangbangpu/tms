package com.chinaway.tms.basic.service;

import com.chinaway.tms.basic.model.Userinfo;
import com.chinaway.tms.core.BaseService;

public interface UserinfoService extends BaseService<Userinfo, Integer> {
	
}
