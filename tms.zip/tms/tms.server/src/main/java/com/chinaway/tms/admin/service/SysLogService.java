package com.chinaway.tms.admin.service;

import com.chinaway.tms.admin.model.SysLog;
import com.chinaway.tms.core.BaseService;

public interface SysLogService extends BaseService<SysLog, Integer> {
	
}
