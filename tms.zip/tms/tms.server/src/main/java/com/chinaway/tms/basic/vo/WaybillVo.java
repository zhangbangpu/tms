package com.chinaway.tms.basic.vo;

/**
 * g7系统的运单（车次）
 * @author shu
 *
 */
public class WaybillVo {
	private String xx;	//xx
}
