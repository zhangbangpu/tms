package com.chinaway.tms.admin.dao;

import com.chinaway.tms.admin.model.SysUserRole;
import com.chinaway.tms.core.BaseMapper;

public interface SysUserRoleMapper extends BaseMapper<SysUserRole, Integer> {
	
}