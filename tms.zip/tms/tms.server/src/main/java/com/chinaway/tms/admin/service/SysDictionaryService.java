package com.chinaway.tms.admin.service;

import com.chinaway.tms.admin.model.SysDictionary;
import com.chinaway.tms.core.BaseService;

public interface SysDictionaryService extends BaseService<SysDictionary, Integer> {
	
}
