package com.chinaway.tms.basic.dao;

import com.chinaway.tms.basic.model.Userinfo;
import com.chinaway.tms.core.BaseMapper;

public interface UserinfoMapper extends BaseMapper<Userinfo, Integer> {
	
}