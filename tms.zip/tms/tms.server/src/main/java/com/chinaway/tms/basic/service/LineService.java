package com.chinaway.tms.basic.service;

import com.chinaway.tms.basic.model.Line;
import com.chinaway.tms.core.BaseService;

public interface LineService extends BaseService<Line, Integer> {
	
}
