package com.chinaway.tms.admin.service;

import com.chinaway.tms.admin.model.SysUserRole;
import com.chinaway.tms.core.BaseService;

public interface SysUserRoleService extends BaseService<SysUserRole, Integer> {
	
}
