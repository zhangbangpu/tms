package com.chinaway.tms.admin.dao;

import com.chinaway.tms.admin.model.SysRoleMenu;
import com.chinaway.tms.core.BaseMapper;

public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu, Integer> {
	
}