package com.chinaway.tms.basic.dao;

import com.chinaway.tms.basic.model.Line;
import com.chinaway.tms.core.BaseMapper;

public interface LineMapper extends BaseMapper<Line, Integer> {
	
}