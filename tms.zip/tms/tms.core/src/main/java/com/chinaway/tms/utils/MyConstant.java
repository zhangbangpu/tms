package com.chinaway.tms.utils;

/**
 * 常量类
 * @author shu
 *
 */
public class MyConstant {
	/**状态：可用*/
	public static final String ENABLE ="1";
	/**状态：不可用*/
	public static final String DISABLE ="0";
	
	/**状态：不可用*/
	public static final String ORDER_START ="2";

}
